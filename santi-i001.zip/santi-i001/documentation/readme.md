# Documentación del proceso

## Metadata
- Nombre de proceso:
- Peridiocidad de las ejecuciones (diario, semanal, mensual): 
- Tiempo estimado de ejecución:

## Input
- Archivo 1: descripción del input
- Archivo 2: descripción del input

## Output
- Reporte de ejecución
- Reporte X : descripción del output
- Archivo output 1: descripción del output

## Business exceptions:
- BE1:
- BE2:

## Consideraciones especiales (casos bordes, precuaciones, formas de uso)
- 
